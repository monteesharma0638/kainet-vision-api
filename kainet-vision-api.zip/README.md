# kainet-vision-node-api
Node.js Api's for Kainnet vision web app. (Need Mongodb running service)
