const rpc = {
  eth: "https://mainnet.infura.io/v3/e26a969141a34ca784a0ed9e5c2a1811",
};
export default rpc;
