export default {
  ethereum: "ether",
  bsc: "bsc",
  matic: "polygon",
  ethpow: "ethw",
  ethclassic: "etc",
  celo_alfajores: "celo",
  celo_baklava: "celo",
  celo_rc1: "celo",
  velas: "velas",
  avalanche: "avalanche",
  fantom: "fantom",
  moonbeam: "moonbeam"
}