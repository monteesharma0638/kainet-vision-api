export default {
  1: "ethereum",
  137: "matic",
  10001: "ethclassic",
  56: "bsc"
}